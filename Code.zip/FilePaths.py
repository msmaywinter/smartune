import  os

llamaFactory = "../../LLaMA-Factory/"

modelPath = "data"

modelsJson = "dataset_info.json"

currentPath = os.getcwd()


