import json
import os
import glob
import random
import subprocess

from datetime import datetime


import FilePaths
from  Log import  log_to_file
from llamafactory.chat import ChatModel
from llamafactory.extras.misc import torch_gc
from trainingConfig import TrainingConfig

currentPath = os.getcwd()


basePath = os.getcwd()

models = {
    "llama-3-8b-instruct":"meta-llama/Meta-Llama-3-8B-Instruct"
}

############################################
#               global variables
messages = []
outputDir = ""
chat_model: ChatModel
baseModel = ""
projectID = ""


def startTrain(config_path):
    config = TrainingConfig.from_directory(config_path)
    addDatasetRow(config.dataset_path,config.projectID)
    defineParameters(
        models[config.model_name],
                     config.learning_rate,
                     config.num_epochs,
                     config.warmup_ratio,
                     config.max_seq_length,
                     config.fp16,
                     config.batch_size,
                     config.gradient_accumulation_steps
                     )
    #def defineParameters(base_model,learningRate,epochs,warmupRatio,maxLength,FP16,batchSize,gradientAccumulationSteps)
def reset():
    global messages,outputDir,chat_model,baseModel,projectID
    messages = []
    outputDir = ""
    chat_model = None
    baseModel = ""
    projectID = ""
    torch_gc()

def createDB(filePath):
    with open(f"{filePath}","r",encoding="utf-8") as f:
        data = json.load(f)

    allD = []
    for i in data:
        example = {
            "instruction": i["question"],
            "input":"",
            "output": i["answer"]
        }
        allD.append(example)
    return allD

def addDatasetRow(filePath,project_ID):
    global outputDir,projectID
    projectID = project_ID
    outputDir = f"{projectID}_{datetime.now().strftime('%d%m%H%M%S')}"

    os.makedirs(outputDir,exist_ok=True)


    data = createDB(filePath)
    with open(f'{FilePaths.llamaFactory}/{FilePaths.modelPath}/training_data_{outputDir}.jsonl', 'w', encoding='utf-8') as f:
        for example in data:
            f.write(json.dumps(example, ensure_ascii=False) + '\n')


    with open(f"{FilePaths.llamaFactory}/{FilePaths.modelPath}/{FilePaths.modelsJson}", "r") as f:
        allModels = json.load(f)
        if not f"{outputDir}" in allModels:
            allModels[f"{outputDir}"] = {
                "file_name": f"training_data_{outputDir}.jsonl"
            }
            with open(f"{FilePaths.llamaFactory}/{FilePaths.modelPath}/{FilePaths.modelsJson}", 'w') as f:
                json.dump(allModels, f, indent=4)
            print(f"Added key: {outputDir}")





def defineParameters(base_model,learningRate,epochs,warmupRatio,maxLength,FP16,batchSize,gradientAccumulationSteps):
    global baseModel
    baseModel = base_model
    os.chdir(currentPath)

    template = "llama3"

    args = dict(
        stage="sft",
        do_train=True,
        model_name_or_path=baseModel,
        dataset=f"{outputDir}",  # use alpaca and identity datasets
        template=template,  # use llama3 prompt template
        finetuning_type="lora",  # use LoRA adapters to save memory
        lora_target="all",  # attach LoRA adapters to all linear layers
        output_dir=outputDir,  # the path to save LoRA adapters
        per_device_train_batch_size=batchSize,  # the batch size
        gradient_accumulation_steps=4,  # the gradient accumulation steps
        lr_scheduler_type="cosine",  # use cosine learning rate scheduler
        logging_steps=10,  # log every 10 steps
        warmup_ratio=warmupRatio,  # use warmup scheduler
        save_steps=1000,  # save checkpoint every 1000 steps
        learning_rate=learningRate,  # the learning rate
        num_train_epochs=epochs,  # the epochs of training
        max_samples=10000,  # use 500 examples in each dataset
        max_grad_norm=gradientAccumulationSteps,  # clip gradient norm to 1.0
        loraplus_lr_ratio=16.0,  # use LoRA+ algorithm with lambda=16.0
        fp16=FP16,  # use float16 mixed precision training
        use_liger_kernel=False,  # use liger kernel for efficient training
        report_to="none",
        trust_remote_code=True,
        cutoff_len =maxLength,  # Adjust based on training needs
    )
    json.dump(args, open(f"{outputDir}/data.json", "w", encoding="utf-8"), indent=2)
    log_to_file(args,f"{outputDir}/parameters.json")
    doTrain()

def doTrain():
    os.chdir(FilePaths.llamaFactory)
    command = ["llamafactory-cli", "train", os.path.join(currentPath,f"{outputDir}/data.json")]
    try:
        # Run the subprocess
        subprocess.run(command, check=True)
        print("Subprocess completed successfully!")
    except subprocess.CalledProcessError as e:
        # Handle the error if the subprocess fails
        print(f"Subprocess failed with exit code {e.returncode}")
    os.chdir(currentPath)

def setTestModel(temperature):
    global chat_model
    os.chdir(FilePaths.llamaFactory)
    testArgs = dict(
      model_name_or_path=baseModel, # use bnb-4bit-quantized Llama-3-8B-Instruct model
      adapter_name_or_path=outputDir,            # load the saved LoRA adapters
      template="llama3",                     # same to the one in training
      finetuning_type="lora",                  # same to the one in training
      quantization_bit=4,
      temperature=temperature,
      trust_remote_code=True,
    )
    chat_model = ChatModel(testArgs)

def question(query,temperature):
    if not chat_model:
        setTestModel(temperature)
    messages.append({"role": "user", "content": query})
    response = ""
    for new_text in chat_model.stream_chat(messages):
        print(new_text, end="", flush=True)
        response += new_text
    messages.append({"role": "assistant", "content": response})
    print(messages)

#addDatasetRow("BookOpenAIQA.json","A1223333")
outputDir = "A1223333_1305121602"
projectID = "A1223333"

baseModel = "meta-llama/Meta-Llama-3-8B-Instruct"
learning_rate = 3e-5
num_train_epochs = 5
warmup_ratio = 0.25
maxLen = 2048
# defineParameters(baseModel,learning_rate,num_train_epochs,warmup_ratio,maxLen,True,2,8)

